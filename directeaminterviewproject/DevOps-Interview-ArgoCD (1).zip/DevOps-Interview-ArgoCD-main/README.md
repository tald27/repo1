# Directeam DevOps interview - ArgoCD
![Build Status](https://github.com/directeam-io/DevOps-Interview-ArgoCD/actions/workflows/ci.yml/badge.svg)
